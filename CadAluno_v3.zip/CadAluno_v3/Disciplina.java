
/**
 * Escreva a descrição da classe Disciplina aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Disciplina {
 
    // Atribitos
    private Texto nomeDisc; 
}
