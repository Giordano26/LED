//Grupo: Antonio Mello, Enzo Maneira, Lucas Benicio, Stefano Giordano
import GUI.GUI;

public class Main {
     public static void main(String args[]){

        GUI ui = new GUI("Josephus 2.0");
        ui.setVisible(true);
        
    }
}
