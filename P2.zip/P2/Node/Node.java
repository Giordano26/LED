package Node;

public class Node {
    public int idP;
    public Node prox;

    public Node(int idP){
        this.idP = idP;
    }
    
}
